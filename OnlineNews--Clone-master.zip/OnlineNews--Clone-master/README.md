#ProthomAlo--CloneOnlineNews

>Prothom-Alo-online-News portal is simple HTML TEMPLATE for your Magazine, News or Blog site. It is cross browser compatible, mobile ready so it will look great on smart phones, tablets as well as laptops and desktop displays. This template suits for any type of website: Sport news, fashion magazine,travel blog…

#Features:<br>

✔Easy to customize<br>
✔Fully Responsive Design<br>
✔Page template and Post fomats<br>
✔HTML5 Base Template<br>
✔HTML5 & CSS3 <br>
✔Pixel Perfect Design<br> 
✔Responsive Design <br>
✔User Friendly Code <br>
✔Clean Markup <br>
✔Creative Design <br>
✔Cross Browser Support <br>
✔Powered With Bootstrap 3 <br>
✔Used font awesome icon <br>
✔Google Font <br>



#Source & Credits<br>

1.BootStrap<br> 
2.Google font<br> 
3.Jquery Library<br>
4.Font Awesome <br>
